/* Service Worker — منصة ملاذ المعلم */

// ⚠️ غيّري هذا الاسم مع كل نشر جديد (مثلاً: malaz-v35-2026-11-06) لتُحدَّث الملفات المخزنة.
const CACHE_NAME = 'malaz-v35-2026-11-06';

const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/privacy.html',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/logo.png',
  '/icons/apple-touch-icon.png',
  '/fonts/cairo-400.woff2',
  '/fonts/cairo-500.woff2',
  '/fonts/cairo-600.woff2',
  '/fonts/cairo-700.woff2',
  '/fonts/cairo-800.woff2',
  '/fonts/cairo-900.woff2'
];

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE_URLS)));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// يدعم زر «إعادة تحميل الآن» في التطبيق
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

// شبكة أولاً، لكن إن تأخرت أكثر من 3 ثوانٍ نعرض النسخة المخزنة فوراً
// (ويستمر الطلب في الخلفية لتحديث التخزين)
const NETWORK_TIMEOUT_MS = 3000;

function networkFirst(request){
  const fromCache = () => caches.match(request, { ignoreSearch: true })
    .then(hit => hit || caches.match('/index.html'));

  return new Promise(resolve => {
    let settled = false;
    const done = res => { if (!settled) { settled = true; resolve(res); } };

    const timer = setTimeout(() => {
      fromCache().then(hit => { if (hit) done(hit); });
    }, NETWORK_TIMEOUT_MS);

    fetch(request)
      .then(response => {
        clearTimeout(timer);
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
        }
        done(response);
      })
      .catch(() => {
        clearTimeout(timer);
        fromCache().then(hit => done(hit || Response.error()));
      });
  });
}

function cacheFirst(request){
  return caches.match(request).then(hit => {
    if (hit) return hit;
    return fetch(request).then(response => {
      if (response && response.ok && response.type === 'basic') {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
      }
      return response;
    });
  });
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  const path = url.pathname;
  if (path === '/' || path === '/index.html' || path === '/sw.js') {
    event.respondWith(networkFirst(request));
  } else {
    event.respondWith(cacheFirst(request));
  }
});
