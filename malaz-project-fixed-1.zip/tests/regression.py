"""اختبارات انحدار لإصلاحات هذه الجلسة. تُشغَّل على نسختين: الأصلية (يجب أن يفشل الاختبار) والمعدَّلة (يجب أن ينجح)."""
import json, sys, os, threading, http.server, socketserver, functools, tempfile, shutil
from playwright.sync_api import sync_playwright

def serve(directory, port):
    class Q(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*a): pass
    socketserver.TCPServer.allow_reuse_address = True
    srv = socketserver.TCPServer(('127.0.0.1', port), functools.partial(Q, directory=directory))
    threading.Thread(target=srv.serve_forever, daemon=True).start(); return srv

SESSION = "{access_token:'a',refresh_token:'r',expires_at:Math.floor(Date.now()/1000)+3600,email:'t@t.com'}"

def open_app(p, port, seed_fn=None):
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width':390,'height':844}); page = ctx.new_page()
    errs = []; page.on('pageerror', lambda e: errs.append(str(e)[:160]))
    page.on('dialog', lambda d: d.accept())
    ctx.route('**/*', lambda r: r.continue_() if r.request.url.startswith('http://127.0.0.1') else r.fulfill(status=200, content_type='application/json', body='[]'))
    page.goto(f'http://127.0.0.1:{port}/index.html')
    data = page.evaluate("() => JSON.parse(JSON.stringify(defaultMultiData))")
    if seed_fn: seed_fn(data)
    page.evaluate("([k,d]) => { localStorage.setItem(k, JSON.stringify(d)); localStorage.setItem('malaz_sb_session', JSON.stringify(" + SESSION + ")); }", ['myclass_multidata_malaz_v20', data])
    page.reload(); page.wait_for_timeout(1200)
    return b, page, errs

def test_csv(port):
    def seed(d):
        a = d['accounts']['acc_1']
        a['students'] = [{"id":"S-OLD-1","name":"محمد الحسن","gender":"male","father":"محمد","mother":"فاطمة","phone":"","health":"","status":"regular",
                          "contactLog":[{"t":"call"}],"certificateCount":2,"certificatesLog":[{"x":1}]}]
    csv = "رقم,الاسم,الجنس,الأب,الأم,الهاتف,الحالة,الشهادات,الصحة\n1,محمد الحسن,ذكر,محمد,فاطمة,0999,,2,\n2,ليلى أحمد,أنثى,أحمد,سعاد,,,0,\n"
    with sync_playwright() as p:
        b, page, errs = open_app(p, port, seed)
        f = tempfile.NamedTemporaryFile('w', suffix='.csv', delete=False, encoding='utf-8'); f.write(csv); f.close()
        page.set_input_files('#excelFileInput', f.name); page.wait_for_timeout(600)
        res = page.evaluate("appData.students.map(s => ({id:s.id,name:s.name,log:(s.contactLog||[]).length,cl:(s.certificatesLog||[]).length}))")
        b.close()
    kept = [r for r in res if r['name'] == 'محمد الحسن']
    ok = len(res) == 2 and kept and kept[0]['id'] == 'S-OLD-1' and kept[0]['log'] == 1 and kept[0]['cl'] == 1
    return ok, res

def test_restore_old_schema(port):
    old = {"schemaVersion": 18, "activeAccountId": "acc_9", "accounts": {"acc_9": {"username": "t", "teacherName": "م", "students": [], "semestersData": {}}}}
    with sync_playwright() as p:
        b, page, errs = open_app(p, port)
        f = tempfile.NamedTemporaryFile('w', suffix='.json', delete=False, encoding='utf-8'); json.dump(old, f); f.close()
        page.set_input_files('#backupFileInput', f.name); page.wait_for_timeout(900)
        ver = page.evaluate("multiData.schemaVersion"); snap = page.evaluate("!!localStorage.getItem('malaz_prerestore_snapshot')")
        active = page.evaluate("multiData.activeAccountId")
        b.close()
    return (ver == 21 and active == 'acc_9', {'schemaVersion': ver, 'snapshot': snap, 'active': active, 'errors': errs})

if __name__ == '__main__':
    here = os.path.dirname(os.path.abspath(__file__))
    new_dir = os.path.join(here, '..', 'www'); orig = sys.argv[1] if len(sys.argv) > 1 else None
    targets = [('المعدَّلة', new_dir, 8771)] + ([('الأصلية', orig, 8772)] if orig else [])
    for label, d, port in targets:
        srv = serve(d, port)
        r1 = test_csv(port); r2 = test_restore_old_schema(port)
        print(f'[{label}] استيراد CSV يحفظ المعرّف والسجلات: {"نجح" if r1[0] else "فشل"} {r1[1]}')
        print(f'[{label}] استعادة نسخة قديمة تُرقّى للمخطط 21: {"نجح" if r2[0] else "فشل"} {r2[1]}')
        srv.shutdown()
