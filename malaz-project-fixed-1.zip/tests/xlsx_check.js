// يولّد ملف XLSX تجريبي بالعربية عبر export-kit.js ويحفظه للتحقق منه بـ openpyxl وLibreOffice
global.window = {}; global.document = {}; 
require('../www/export-kit.js');
const fs = require('fs');
(async () => {
  const blob = window.MalazFiles.buildXlsx([
    { name: 'الطلاب', title: ['مدرسة الأمل — الصف الثاني', 'المعلمة: سعاد'], headers: ['الرقم', 'الاسم', 'الهاتف', 'ملاحظة'],
      rows: [[1, 'محمد الحسن', '0999123456', '=1+1'], [2, 'ليلى <أحمد> & "ابنة"', '+963', '@cmd'], [3, 'سارة', '', 'a\u0001b'], [4, 'رقم', 3.5, null]] },
    { name: 'الطلاب', headers: ['x'], rows: [[1]] },                       // اسم مكرر
    { name: 'اسم طويل جدا جدا جدا جدا جدا جدا جدا جدا جدا:؟', headers: ['أ'], rows: [] }
  ]);
  fs.writeFileSync('/tmp/test.xlsx', Buffer.from(await blob.arrayBuffer()));
  console.log('written', blob.size, 'bytes');
})();
