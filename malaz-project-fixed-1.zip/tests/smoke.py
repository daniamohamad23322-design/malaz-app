"""اختبار دخان حقيقي: يحمّل التطبيق في Chromium، يحقن بيانات تحتوي حمولات XSS،
يتنقل بين كل الصفحات، ويسجّل أخطاء JavaScript وأي تنفيذ للحمولة. Supabase مُحاكى (لا اتصال حقيقي)."""
import json, sys, threading, http.server, socketserver, functools, os
from playwright.sync_api import sync_playwright

WWW = os.path.join(os.path.dirname(__file__), '..', 'www')
PORT = 8765
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
h = functools.partial(Q, directory=WWW)
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', PORT), h)
threading.Thread(target=srv.serve_forever, daemon=True).start()

XSS = '<img src=x onerror="window.__xss=(window.__xss||0)+1">'
XSS_ATTR = '\'"><img src=x onerror="window.__xss=(window.__xss||0)+1">'

def seed():
    st = lambda i, nm: {"id": str(i), "name": nm, "gender": "male", "father": XSS, "mother": XSS_ATTR,
        "phone": "0999" + XSS, "health": XSS, "status": "regular", "contactLog": [], "certificateCount": 0, "certificatesLog": []}
    return st

pages = ['homePage','schedulePage','studentsPage','attendancePage','monthlyReportPage','examsPage','quizzesPage',
 'behaviorPage','classworkPage','spellingPage','quranPage','certificatesPage','bookDistributionPage','booksLibraryPage',
 'notebookPage','notesPage','fundPage','settingsPage','seatingChartPage','instantPointsPage','analyticsPage',
 'smartBoardPage','comprehensiveReportPage','curriculumPage']

def run(payload=True):
    errors, reqs = [], []
    with sync_playwright() as p:
        b = p.chromium.launch(); ctx = b.new_context(viewport={'width':390,'height':844}, locale='ar')
        page = ctx.new_page()
        page.on('pageerror', lambda e: errors.append('PAGEERROR: ' + str(e)[:200]))
        page.on('console', lambda m: errors.append('CONSOLE.' + m.type + ': ' + m.text[:200]) if m.type == 'error' else None)
        def route(r):
            u = r.request.url
            if 'supabase.co' in u:
                reqs.append(r.request.method + ' ' + u.split('supabase.co')[1][:60])
                if '/auth/v1/token' in u:
                    return r.fulfill(status=200, content_type='application/json', body=json.dumps({"access_token":"a","refresh_token":"r","expires_in":3600,"token_type":"bearer","user":{"id":"u1","email":"t@t.com"}}))
                if r.request.method == 'GET': return r.fulfill(status=200, content_type='application/json', body='[]')
                return r.fulfill(status=201, content_type='application/json', body='[]')
            if u.startswith('http://127.0.0.1'): return r.continue_()
            reqs.append('BLOCKED ' + u[:80]); return r.abort()
        ctx.route('**/*', route)
        page.goto(f'http://127.0.0.1:{PORT}/index.html')
        stfn = seed()
        data = page.evaluate("() => JSON.parse(JSON.stringify(defaultMultiData))")
        acc = data['accounts']['acc_1']
        if payload:
            acc['students'] = [stfn(i, XSS + ' ' + XSS_ATTR) for i in range(1, 4)]
            acc['teacherName'] = XSS; acc['schoolName'] = XSS_ATTR
            acc['notes'] = [{"id":"n1","text":XSS,"category":"normal","done":False}]
        page.evaluate("""([k,d]) => { localStorage.setItem(k, JSON.stringify(d));
            localStorage.setItem('malaz_sb_session', JSON.stringify({access_token:'a',refresh_token:'r',expires_at:Math.floor(Date.now()/1000)+3600,email:'t@t.com',user_id:'u1'})); }""",
            ['myclass_multidata_malaz_v20', data])
        page.reload(); page.wait_for_timeout(1500)
        for pg in pages:
            try:
                page.evaluate(f"navigateTo('{pg}')"); page.wait_for_timeout(250)
            except Exception as e:
                errors.append(f'NAV {pg}: {str(e)[:120]}')
        xss = page.evaluate("window.__xss || 0")
        locked = page.evaluate("document.documentElement.className")
        b.close()
    return errors, reqs, xss, locked

if __name__ == '__main__':
    errors, reqs, xss, locked = run(payload=True)
    print('html class:', locked)
    print('XSS executions:', xss)
    print('errors:', len(errors))
    for e in sorted(set(errors))[:25]: print('  ', e)
    print('network:', sorted(set(reqs))[:12])
    srv.shutdown()
