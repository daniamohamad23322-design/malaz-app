"""اختبار تدفق التصدير والاستعادة فعلياً في Chromium: ينزّل الملفات الحقيقية ثم يفتحها ببرامج خارجية (openpyxl) للتحقق من محتواها."""
import json, os, sys, threading, http.server, socketserver, functools, tempfile, hashlib
from playwright.sync_api import sync_playwright
import openpyxl

HERE = os.path.dirname(os.path.abspath(__file__)); WWW = os.path.join(HERE, '..', 'www'); PORT = 8781
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(('127.0.0.1', PORT), functools.partial(Q, directory=WWW)); threading.Thread(target=srv.serve_forever, daemon=True).start()

results = []
def check(name, cond, detail=''):
    results.append((name, bool(cond), detail)); print(('PASS ' if cond else 'FAIL ') + name + (' — ' + str(detail) if detail and not cond else ''))

SESSION = "{access_token:'a',refresh_token:'r',expires_at:Math.floor(Date.now()/1000)+3600,email:'t@t.com'}"
def seed(d, subj):
    a = d['accounts']['acc_1']; a['semester'] = 1
    a['students'] = [
        {"id":"s1","name":"محمد الحسن","gender":"male","father":"محمد","mother":"فاطمة","phone":"0999123456","health":"","status":"regular","contactLog":[],"certificateCount":1,"certificatesLog":[]},
        {"id":"s2","name":"ليلى <أحمد> & \"ابنة\"","gender":"female","father":"أحمد","mother":"سعاد","phone":"","health":"ضعف بصر","status":"transferred","contactLog":[],"certificateCount":0,"certificatesLog":[]},
        {"id":"s3","name":"=HYPERLINK(\"http://x\")","gender":"male","father":"","mother":"","phone":"","health":"","status":"regular","contactLog":[],"certificateCount":0,"certificatesLog":[]}]
    t = a['semestersData']['1']
    t['attendance'] = {"2026-10-04": {"s1":"present","s2":"absent","s3":"late"}, "2026-10-05": {"s1":"present","s2":"excused"}, "2026-10-06": {"s1":"absent","s2":"absent"}}
    t['exams'] = {"s1": {subj[0]: 90, subj[1]: 80}, "s2": {subj[0]: 70}}
    t['quizzes'] = {"first": {"s1": {subj[0]: 18}}, "second": {"s2": {subj[1]: 15}}}
    t['behaviorWeeklyArchive'] = {"current": {"الأحد": {"s1": 10, "s2": 7}, "الاثنين": {"s1": 9}}, "previous": {}}
    t['spelling'] = {"s1": 20}
    t['classwork'] = {"2026-10-04": {"subject": "عربي", "lesson": "درس ١", "status": {"s1": "done"}}}
    t['homework'] = {"2026-10-05": {"subject": "رياضيات", "lesson": "", "status": {"s2": "done", "s1": "done"}}}

with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width':390,'height':844}, accept_downloads=True); page = ctx.new_page()
    errs = []; page.on('pageerror', lambda e: errs.append(str(e)[:200]))
    dialogs = []; mode = {'accept': True}
    def on_dialog(d): dialogs.append(d.message); d.accept() if mode['accept'] else d.dismiss()
    page.on('dialog', on_dialog)
    ctx.route('**/*', lambda r: r.continue_() if r.request.url.startswith('http://127.0.0.1') else r.fulfill(status=200, content_type='application/json', body='[]'))
    page.goto(f'http://127.0.0.1:{PORT}/index.html')
    subj = page.evaluate("OFFICIAL_SUBJECTS.map(s => s.key)")
    data = page.evaluate("() => JSON.parse(JSON.stringify(defaultMultiData))"); seed(data, subj)
    page.evaluate("([k,d]) => { localStorage.setItem(k, JSON.stringify(d)); localStorage.setItem('malaz_sb_session', JSON.stringify(" + SESSION + ")); }", ['myclass_multidata_malaz_v20', data])
    page.reload(); page.wait_for_timeout(1200)

    def dl(js):
        with page.expect_download(timeout=8000) as di: page.evaluate(js)
        d = di.value; path = os.path.join(tempfile.gettempdir(), d.suggested_filename); d.save_as(path); return d.suggested_filename, path

    # --- واجهة مركز التصدير
    page.evaluate("navigateTo('settingsPage')"); page.wait_for_timeout(200)
    check('عنصر «مركز التصدير» ظاهر في الإعدادات', page.evaluate("!!Array.from(document.querySelectorAll('#settingsPage .setting-menu-item h4')).find(h => h.textContent.includes('مركز التصدير'))"))
    page.evaluate("openExportCenter()"); page.wait_for_timeout(200)
    check('نافذة مركز التصدير تُفتح', page.evaluate("document.getElementById('exportCenterModal').classList.contains('show')"))

    # --- XLSX لكل قسم
    name, path = dl("MalazExport.students()"); wb = openpyxl.load_workbook(path); ws = wb.worksheets[0]; rows = list(ws.iter_rows(values_only=True))
    check('XLSX الطلاب: اسم الملف .xlsx وبالعربية', name.endswith('.xlsx') and 'كشف_الطلاب' in name, name)
    check('XLSX الطلاب: 3 صفوف بيانات + عناوين', len(rows) == 3 + 1 + 3, len(rows))
    check('XLSX الطلاب: العربية سليمة والرموز الخاصة محفوظة', rows[4][1] == 'محمد الحسن' and rows[5][1] == 'ليلى <أحمد> & "ابنة"', rows[4:6])
    check('XLSX الطلاب: نص يشبه الصيغة يبقى نصاً', ws['B7'].data_type == 's' and str(ws['B7'].value).startswith('=HYPERLINK'), (ws['B7'].data_type, ws['B7'].value))
    check('XLSX الطلاب: الهاتف يبقى نصاً مع الصفر', ws['F5'].value == '0999123456' and ws['F5'].data_type == 's', ws['F5'].value)
    check('XLSX الطلاب: الحالة «منقول»', ws['G6'].value == 'منقول', ws['G6'].value)
    check('XLSX الطلاب: اتجاه الورقة RTL', ws.sheet_view.rightToLeft is True)

    name, path = dl("MalazExport.attendance()"); ws = openpyxl.load_workbook(path).worksheets[0]; rows = list(ws.iter_rows(values_only=True))
    hdr = rows[3]; r1 = rows[4]; r2 = rows[5]
    check('XLSX الحضور: أعمدة التواريخ الثلاثة', hdr[6:] == ('2026-10-04', '2026-10-05', '2026-10-06'), hdr)
    check('XLSX الحضور: محمد حاضر2 غائب1', r1[2:6] == (2, 1, 0, 0), r1[2:6])
    check('XLSX الحضور: ليلى غائب2 بعذر1', r2[2:6] == (0, 2, 0, 1), r2[2:6])
    check('XLSX الحضور: خلايا الحالة بالعربية', r1[6:] == ('حاضر', 'حاضر', 'غائب'), r1[6:])

    name, path = dl("MalazExport.exams()"); ws = openpyxl.load_workbook(path).worksheets[0]; rows = list(ws.iter_rows(values_only=True))
    check('XLSX الجلاء: المجموع والمعدل لمحمد = 170 و 85', rows[4][-2] == 170 and rows[4][-1] == 85, rows[4][-3:])
    check('XLSX الجلاء: الدرجات رقمية', isinstance(rows[4][2], (int, float)), rows[4][2])

    name, path = dl("MalazExport.quizzes()"); wb = openpyxl.load_workbook(path)
    check('XLSX المذاكرات: ورقتان', len(wb.sheetnames) == 2, wb.sheetnames)
    check('XLSX المذاكرات: 18 لمحمد في الأولى', list(wb.worksheets[0].iter_rows(values_only=True))[4][2] == 18)

    name, path = dl("MalazExport.behavior()"); ws = openpyxl.load_workbook(path).worksheets[0]; r1 = list(ws.iter_rows(values_only=True))[4]
    check('XLSX السلوك: أحد=10 اثنين=9 مجموع=19 إملاء=20', r1[2] == 10 and r1[3] == 9 and r1[7] == 19 and r1[-1] == 20, r1)

    name, path = dl("MalazExport.homework()"); wb = openpyxl.load_workbook(path)
    check('XLSX الواجبات: ورقتان (صفي/منزلي)', len(wb.sheetnames) == 2, wb.sheetnames)
    r = list(wb.worksheets[1].iter_rows(values_only=True))
    check('XLSX الواجبات المنزلية: محمد وليلى أنجزا', r[4][2] == 1 and r[5][2] == 1, r[4:6])

    name, path = dl("MalazExport.all()"); wb = openpyxl.load_workbook(path)
    check('XLSX الشامل: 8 أوراق بأسماء فريدة', len(wb.sheetnames) == 8 and len(set(wb.sheetnames)) == 8, wb.sheetnames)
    info = page.evaluate("document.getElementById('mzLastFile').textContent")
    check('عرض اسم الملف ونوعه وحجمه في المركز', 'XLSX' in info and 'ك.ب' in info and '.xlsx' in info, info)

    # --- حالة فارغة: لا تلاميذ
    page.evaluate("const _s = appData.students; window.__bk = _s; appData.students = [];")
    page.evaluate("MalazExport.students()"); page.wait_for_timeout(200)
    check('تصدير بلا تلاميذ يعطي تنبيهاً ولا ينزّل', 'لا يوجد تلاميذ' in page.evaluate("document.getElementById('toast').textContent"))
    page.evaluate("appData.students = window.__bk")

    # --- CSV القديم يعمل
    name, path = dl("exportStudentsToExcel()"); raw = open(path, 'rb').read()
    check('CSV القديم: BOM + عربية', raw.startswith(b'\xef\xbb\xbf') and 'محمد الحسن'.encode() in raw, name)

    # --- النسخة الاحتياطية: بصمة + استعادة
    name, path = dl("exportBackupFile()"); txt = open(path, encoding='utf-8').read(); bk = json.loads(txt)
    meta = bk.pop('_meta', None)
    check('النسخة الاحتياطية: _meta موجود', meta and meta['students'] == 3 and meta['schema'] == 21, meta)
    check('النسخة الاحتياطية: البصمة تطابق SHA-256 للمحتوى', meta and hashlib.sha256(json.dumps(bk, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest() == meta['sha256'])
    # استعادة سليمة
    page.evaluate("appData.students = []; saveData();")
    dialogs.clear(); page.set_input_files('#backupFileInput', path); page.wait_for_timeout(900)
    check('الاستعادة: التلاميذ عادوا', page.evaluate("appData.students.length") == 3, page.evaluate("appData.students.length"))
    check('الاستعادة: رسالة التأكيد تعرض عدد الحسابات والتلاميذ', any('3 تلميذ' in m for m in dialogs), dialogs)
    check('الاستعادة: لقطة الأمان محفوظة', page.evaluate("!!localStorage.getItem('malaz_prerestore_snapshot')"))
    # ملف معدَّل يدوياً
    tampered = txt.replace('محمد الحسن', 'محمد المعدَّل'); tp = os.path.join(tempfile.gettempdir(), 'tampered.json'); open(tp, 'w', encoding='utf-8').write(tampered)
    mode['accept'] = False; dialogs.clear(); page.set_input_files('#backupFileInput', tp); page.wait_for_timeout(700); mode['accept'] = True
    check('ملف معدَّل: تحذير البصمة يظهر والاستعادة تُرفض', any('بصمة التحقق' in m for m in dialogs) and page.evaluate("appData.students[0].name") == 'محمد الحسن', dialogs)
    # ملف ليس نسخة ملاذ
    junk = os.path.join(tempfile.gettempdir(), 'junk.json'); open(junk, 'w').write('{"hello": 1}')
    page.set_input_files('#backupFileInput', junk); page.wait_for_timeout(500)
    check('ملف غريب: يُرفض ولا يمس البيانات', page.evaluate("appData.students.length") == 3)

    # --- صورة جدول الحصص
    name, path = dl("exportScheduleAsImage()"); sig = open(path, 'rb').read(8)
    check('صورة الجدول: PNG حقيقي', sig == b'\x89PNG\r\n\x1a\n' and os.path.getsize(path) > 2000, (name, os.path.getsize(path)))

    # --- معاينة PDF/طباعة
    for t in ('students', 'attendance', 'exams', 'schedule', 'fund'):
        page.evaluate(f"openPrintPreviewModal('{t}')"); page.wait_for_timeout(150)
        n = page.evaluate("document.getElementById('printSheetBody').innerText.length")
        check(f'معاينة الطباعة/PDF: {t} فيها محتوى', n > 30, n)
        page.evaluate("closeModal('printPreviewModal')")

    check('لا أخطاء JavaScript أثناء الاختبار', not errs, errs[:3])
    b.close()

srv.shutdown()
bad = [r for r in results if not r[1]]
print(f'\n{len(results) - len(bad)}/{len(results)} نجح')
sys.exit(1 if bad else 0)
