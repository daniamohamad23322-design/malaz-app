#!/bin/bash
# يُشغَّل بعد "npx cap add android": يضيف الإضافات ومكوّن الطباعة
set -e
for p in filesystem share local-notifications; do
  npm install --legacy-peer-deps "@capacitor/$p@latest-8" \
    || npm install --legacy-peer-deps "@capacitor/$p@^8.0.0" \
    || npm install --legacy-peer-deps "@capacitor/$p"
done
MAIN=$(find android/app/src/main/java -name MainActivity.java | head -1)
DIR=$(dirname "$MAIN")
PKG=$(grep -m1 '^package ' "$MAIN" | sed -E 's/^package ([^;]+);.*/\1/')
echo "package: $PKG"
sed "s/__PKG__/$PKG/g" native/PrintHtmlPlugin.java.txt > "$DIR/PrintHtmlPlugin.java"
sed "s/__PKG__/$PKG/g" native/MainActivity.java.txt > "$MAIN"
MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q POST_NOTIFICATIONS "$MANIFEST"; then
  sed -i 's#</manifest>#    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n</manifest>#' "$MANIFEST"
fi
cat "$DIR/MainActivity.java"
