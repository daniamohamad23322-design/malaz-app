/* ملاذ المعلم — أدوات التصدير: مولّد XLSX بلا مكتبات خارجية + مساعد التنزيل وعرض معلومات الملف.
   يعمل دون إنترنت، ويدعم العربية (UTF-8) واتجاه الورقة من اليمين لليسار. */
(function(){
  'use strict';

  /* ---------- CRC32 + ZIP (بدون ضغط STORE) ---------- */
  var CRC_TABLE = (function(){
    var t = new Uint32Array(256);
    for(var n = 0; n < 256; n++){ var c = n; for(var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); t[n] = c >>> 0; }
    return t;
  })();
  function crc32(u8){ var c = 0xFFFFFFFF; for(var i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  var enc = new TextEncoder();
  function zipStore(files){
    var parts = [], central = [], offset = 0;
    var d = new Date();
    var dosTime = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    var dosDate = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    files.forEach(function(f){
      var name = enc.encode(f.name), data = (typeof f.data === 'string') ? enc.encode(f.data) : f.data, crc = crc32(data);
      var lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
      lh.setUint16(10, dosTime, true); lh.setUint16(12, dosDate, true); lh.setUint32(14, crc, true);
      lh.setUint32(18, data.length, true); lh.setUint32(22, data.length, true); lh.setUint16(26, name.length, true); lh.setUint16(28, 0, true);
      parts.push(new Uint8Array(lh.buffer), name, data);
      var ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true);
      ch.setUint16(12, dosTime, true); ch.setUint16(14, dosDate, true); ch.setUint32(16, crc, true);
      ch.setUint32(20, data.length, true); ch.setUint32(24, data.length, true); ch.setUint16(28, name.length, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);
      offset += 30 + name.length + data.length;
    });
    var cSize = 0; central.forEach(function(p){ cSize += p.length; });
    var end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
    end.setUint32(12, cSize, true); end.setUint32(16, offset, true);
    return new Blob(parts.concat(central, [new Uint8Array(end.buffer)]), { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }

  /* ---------- XLSX ---------- */
  function xmlEsc(v){
    return String(v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function colName(i){ var s = ''; i++; while(i > 0){ var m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
  function sheetName(n, used){
    var base = String(n || 'ورقة').replace(/[\[\]:*?\/\\]/g, ' ').replace(/^'+|'+$/g, '').trim().slice(0, 31) || 'ورقة';
    var out = base, k = 2;
    while(used[out.toLowerCase()]){ var suf = ' ' + k++; out = base.slice(0, 31 - suf.length) + suf; }
    used[out.toLowerCase()] = true; return out;
  }
  function cellXml(ref, v, style){
    if(v === null || v === undefined || v === '') return '<c r="' + ref + '" s="' + style + '"/>';
    if(typeof v === 'number' && isFinite(v)) return '<c r="' + ref + '" s="' + (style === 2 ? 3 : style) + '"><v>' + v + '</v></c>';
    return '<c r="' + ref + '" s="' + style + '" t="inlineStr"><is><t xml:space="preserve">' + xmlEsc(v) + '</t></is></c>';
  }
  /* sheet: { name, title:[سطور عنوان], headers:[...], rows:[[...]], widths:[...] } */
  function sheetXml(sh){
    var title = sh.title || [], headers = sh.headers || [], rows = sh.rows || [];
    var ncol = Math.max(headers.length, rows.reduce(function(m, r){ return Math.max(m, r.length); }, 0), 1);
    var xml = '', r = 0, merges = [];
    title.forEach(function(t){
      r++; xml += '<row r="' + r + '">' + cellXml('A' + r, t, 4) + '</row>';
      if(ncol > 1) merges.push('A' + r + ':' + colName(ncol - 1) + r);
    });
    var headerRow = 0;
    if(headers.length){
      r++; headerRow = r;
      xml += '<row r="' + r + '" ht="24" customHeight="1">' + headers.map(function(h, i){ return cellXml(colName(i) + r, h, 1); }).join('') + '</row>';
    }
    rows.forEach(function(row){
      r++;
      var cells = '';
      for(var i = 0; i < ncol; i++) cells += cellXml(colName(i) + r, row[i], 2);
      xml += '<row r="' + r + '">' + cells + '</row>';
    });
    var widths = sh.widths || [];
    var cols = '';
    for(var i = 0; i < ncol; i++){
      var w = widths[i];
      if(!w){ w = 12; var hv = headers[i] ? String(headers[i]).length + 4 : 0; w = Math.max(w, Math.min(hv, 40)); rows.slice(0, 200).forEach(function(rw){ var l = (rw[i] === undefined || rw[i] === null) ? 0 : String(rw[i]).length + 2; if(l > w) w = Math.min(l, 45); }); }
      cols += '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>';
    }
    var pane = headerRow ? '<pane ySplit="' + headerRow + '" topLeftCell="A' + (headerRow + 1) + '" activePane="bottomLeft" state="frozen"/>' : '';
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>' +
      '<sheetViews><sheetView rightToLeft="1" workbookViewId="0">' + pane + '</sheetView></sheetViews>' +
      '<sheetFormatPr defaultRowHeight="18"/><cols>' + cols + '</cols><sheetData>' + xml + '</sheetData>' +
      (merges.length ? '<mergeCells count="' + merges.length + '">' + merges.map(function(m){ return '<mergeCell ref="' + m + '"/>'; }).join('') + '</mergeCells>' : '') +
      '<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>' +
      '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>';
  }
  var STYLES = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
    '<fonts count="3"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font><font><b/><sz val="13"/><name val="Arial"/></font></fonts>' +
    '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF3B5998"/><bgColor indexed="64"/></patternFill></fill></fills>' +
    '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border></borders>' +
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
    '<cellXfs count="5">' +
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
    '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1" readingOrder="2"/></xf>' +
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1" readingOrder="2"/></xf>' +
    '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' +
    '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center" readingOrder="2"/></xf>' +
    '</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';

  function buildXlsx(sheets){
    sheets = (sheets && sheets.length) ? sheets : [{ name: 'ورقة', headers: [], rows: [] }];
    var used = {}, names = sheets.map(function(s){ return sheetName(s.name, used); });
    var files = [];
    files.push({ name: '[Content_Types].xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + sheets.map(function(_, i){ return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join('') + '</Types>' });
    files.push({ name: '_rels/.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>' });
    files.push({ name: 'xl/workbook.xml', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + names.map(function(n, i){ return '<sheet name="' + xmlEsc(n) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>'; }).join('') + '</sheets></workbook>' });
    files.push({ name: 'xl/_rels/workbook.xml.rels', data: '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + sheets.map(function(_, i){ return '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join('') + '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' });
    files.push({ name: 'xl/styles.xml', data: STYLES });
    sheets.forEach(function(s, i){ files.push({ name: 'xl/worksheets/sheet' + (i + 1) + '.xml', data: sheetXml(s) }); });
    return zipStore(files);
  }

  /* ---------- معلومات الملف + التنزيل ---------- */
  var TYPE_LABEL = { xlsx: 'Excel (XLSX)', csv: 'CSV', json: 'JSON (نسخة احتياطية)', pdf: 'PDF', png: 'صورة PNG', jpg: 'صورة JPG', jpeg: 'صورة JPG', webp: 'صورة WEBP' };
  function humanSize(n){ if(!isFinite(n)) return ''; if(n < 1024) return n + ' بايت'; if(n < 1048576) return (n / 1024).toFixed(1) + ' ك.ب'; return (n / 1048576).toFixed(2) + ' م.ب'; }
  function fileInfo(blob, name){
    var ext = (String(name).split('.').pop() || '').toLowerCase();
    return { name: name, type: TYPE_LABEL[ext] || (blob && blob.type) || ext, size: blob ? blob.size : 0, sizeText: humanSize(blob ? blob.size : 0) };
  }
  function safeFileName(n){ return String(n || 'ملف').replace(/[\\\/:*?"<>|\r\n\t]+/g, '_').replace(/\s+/g, '_').slice(0, 120); }
  function toast(m){ try { if(typeof window.showToast === 'function') window.showToast(m); } catch(e){} }

  /* ينزّل (أو يشارك على أندرويد عبر app-bridge) ويُظهر اسم الملف ونوعه وحجمه. */
  function download(blob, name){
    name = safeFileName(name);
    var info = fileInfo(blob, name);
    try {
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url; a.setAttribute('download', name);
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(function(){ URL.revokeObjectURL(url); }, 30000);
      if(!window.MALAZ_NATIVE) toast('✅ ' + info.name + ' — ' + info.type + ' — ' + info.sizeText);
    } catch(e){
      console.warn('download failed', e);
      toast('⚠️ تعذّر تنزيل الملف: ' + info.name);
      return null;
    }
    return info;
  }
  function downloadXlsx(sheets, name){
    name = /\.xlsx$/i.test(name) ? name : name + '.xlsx';
    return download(buildXlsx(sheets), name);
  }

  window.MalazFiles = { buildXlsx: buildXlsx, download: download, downloadXlsx: downloadXlsx, fileInfo: fileInfo, humanSize: humanSize, safeFileName: safeFileName, crc32: crc32 };
})();
