/* ملاذ المعلم — مركز التصدير والملفات.
   يعتمد على export-kit.js (MalazFiles) وعلى متغيرات التطبيق العامة (appData, OFFICIAL_SUBJECTS ...).
   كل الدوال هنا للقراءة فقط: لا تعدّل بيانات المعلمة. */
(function(){
  'use strict';
  var STATUS_AR = { present: 'حاضر', absent: 'غائب', late: 'متأخر', excused: 'غياب بعذر' };
  var STUDENT_STATUS_AR = { dropout: 'متسرب', frequent_absent: 'غياب متكرر', transferred: 'منقول' };
  var DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];

  function toast(m){ try { showToast(m); } catch(e){} }
  function students(){ return (appData && appData.students) || []; }
  function term(){ return appData.semestersData[String(appData.semester || 1)] || {}; }
  function num(v){ if(v === undefined || v === null || v === '') return ''; var n = parseFloat(v); return isNaN(n) ? String(v) : n; }
  function title(sheetTitle){
    var d = new Date();
    return [
      (appData.schoolName || '') + ' — الصف ' + (appData.grade || '') + (appData.section ? ' (' + appData.section + ')' : ''),
      sheetTitle + ' — الفصل ' + (appData.semester === 2 ? 'الثاني' : 'الأول') + ' — ' + (appData.teacherName || ''),
      'تاريخ التصدير: ' + d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0')
    ];
  }
  function fname(base){ return base + '_' + (appData.schoolName || 'مدرسة') + '_' + new Date().toISOString().slice(0, 10); }
  function needStudents(){ if(!students().length){ toast('⚠️ لا يوجد تلاميذ لتصديرهم'); return false; } return true; }

  /* ---------- بناء الأوراق ---------- */
  function sheetStudents(){
    return { name: 'كشف الطلاب', title: title('كشف الطلاب'),
      headers: ['الرقم', 'اسم التلميذ', 'الجنس', 'اسم الأب', 'اسم الأم', 'هاتف التواصل', 'الحالة الأكاديمية', 'عدد الشهادات', 'التنبيه الصحي'],
      rows: students().map(function(s, i){ return [i + 1, s.name, s.gender === 'female' ? 'أنثى' : 'ذكر', s.father || '', s.mother || '', s.phone || '', STUDENT_STATUS_AR[s.status] || 'منتظم', s.certificateCount || 0, s.health || '']; }) };
  }
  function sheetAttendance(){
    var att = term().attendance || {};
    var dates = Object.keys(att).filter(function(d){ return att[d] && Object.keys(att[d]).length; }).sort();
    var headers = ['الرقم', 'اسم التلميذ', 'حاضر', 'غائب', 'متأخر', 'غياب بعذر'].concat(dates);
    var rows = students().map(function(s, i){
      var c = { present: 0, absent: 0, late: 0, excused: 0 };
      var cells = dates.map(function(d){ var st = att[d][s.id]; if(st && c[st] !== undefined) c[st]++; return STATUS_AR[st] || ''; });
      return [i + 1, s.name, c.present, c.absent, c.late, c.excused].concat(cells);
    });
    return { name: 'الحضور والغياب', title: title('سجل الحضور والغياب'), headers: headers, rows: rows };
  }
  function sheetExams(){
    var t = term(), ranks = {}; try { ranks = computeStudentRanks().rankMap || {}; } catch(e){}
    var headers = ['الرقم', 'اسم التلميذ'].concat(OFFICIAL_SUBJECTS.map(function(x){ return x.name + ' (' + x.max + ')'; }), ['المرتبة', 'المجموع', 'المعدل / 100']);
    var rows = students().map(function(s, i){
      var tot = 0, cnt = 0;
      var vals = OFFICIAL_SUBJECTS.map(function(sub){ var v = t.exams && t.exams[s.id] ? t.exams[s.id][sub.key] : undefined; var n = num(v); if(n !== '' && typeof n === 'number'){ tot += n; cnt++; } return n; });
      return [i + 1, s.name].concat(vals, [ranks[s.id] || '', cnt ? tot : '', cnt ? Math.round(tot / cnt * 100) / 100 : '']);
    });
    return { name: 'الجلاء (الدرجات)', title: title('بطاقة الجلاء — الدرجات'), headers: headers, rows: rows };
  }
  function sheetQuiz(which, label){
    var t = term(), b = (t.quizzes && t.quizzes[which]) || {};
    var headers = ['الرقم', 'اسم التلميذ'].concat(OFFICIAL_SUBJECTS.map(function(x){ return x.name; }), ['المجموع']);
    var rows = students().map(function(s, i){
      var tot = 0, cnt = 0;
      var vals = OFFICIAL_SUBJECTS.map(function(sub){ var n = num(b[s.id] ? b[s.id][sub.key] : undefined); if(n !== '' && typeof n === 'number'){ tot += n; cnt++; } return n; });
      return [i + 1, s.name].concat(vals, [cnt ? tot : '']);
    });
    return { name: label, title: title(label), headers: headers, rows: rows };
  }
  function sheetBehavior(){
    var t = term(), arc = t.behaviorWeeklyArchive || {}, sp = t.spelling || {};
    var headers = ['الرقم', 'اسم التلميذ'];
    var weeks = [['current', 'الأسبوع الحالي'], ['previous', 'الأسبوع السابق']];
    weeks.forEach(function(w){ DAYS.forEach(function(d){ headers.push(w[1] + ' — ' + d); }); headers.push(w[1] + ' — المجموع'); });
    headers.push('درجة الإملاء الحالية');
    var rows = students().map(function(s, i){
      var r = [i + 1, s.name];
      weeks.forEach(function(w){
        var tot = 0, cnt = 0;
        DAYS.forEach(function(d){ var n = num(arc[w[0]] && arc[w[0]][d] ? arc[w[0]][d][s.id] : undefined); if(n !== '' && typeof n === 'number'){ tot += n; cnt++; } r.push(n); });
        r.push(cnt ? tot : '');
      });
      r.push(num(sp[s.id]));
      return r;
    });
    return { name: 'السلوك والإملاء', title: title('السلوك والإملاء'), headers: headers, rows: rows };
  }
  function sheetWork(key, label){
    var bucket = term()[key] || {};
    var dates = Object.keys(bucket).filter(function(d){ return bucket[d] && bucket[d].status && Object.keys(bucket[d].status).length; }).sort();
    var headers = ['الرقم', 'اسم التلميذ', 'عدد المنجز'].concat(dates.map(function(d){ return d + (bucket[d].lesson ? ' — ' + bucket[d].lesson : ''); }));
    var rows = students().map(function(s, i){
      var done = 0;
      var cells = dates.map(function(d){ var ok = bucket[d].status[s.id] === 'done'; if(ok) done++; return ok ? 'أنجز' : 'لم ينجز'; });
      return [i + 1, s.name, done].concat(cells);
    });
    return { name: label, title: title(label), headers: headers, rows: rows };
  }

  /* ---------- أوامر التصدير ---------- */
  var last = null;
  function finish(info){
    last = info;
    var el = document.getElementById('mzLastFile');
    if(el && info) el.textContent = '📁 آخر ملف: ' + info.name + ' — ' + info.type + ' — ' + info.sizeText;
    return info;
  }
  function run(sheets, base){
    try { return finish(MalazFiles.downloadXlsx(sheets, MalazFiles.safeFileName(fname(base)))); }
    catch(e){ console.error('export failed', e); toast('⚠️ تعذّر إنشاء ملف Excel'); return null; }
  }
  var API = {
    students:   function(){ if(!needStudents()) return; return run([sheetStudents()], 'كشف_الطلاب'); },
    attendance: function(){ if(!needStudents()) return; return run([sheetAttendance()], 'سجل_الحضور'); },
    exams:      function(){ if(!needStudents()) return; return run([sheetExams()], 'كشف_الجلاء'); },
    quizzes:    function(){ if(!needStudents()) return; return run([sheetQuiz('first', 'المذاكرة الأولى'), sheetQuiz('second', 'المذاكرة الثانية')], 'المذاكرات'); },
    behavior:   function(){ if(!needStudents()) return; return run([sheetBehavior()], 'السلوك_والإملاء'); },
    homework:   function(){ if(!needStudents()) return; return run([sheetWork('classwork', 'الواجب الصفي'), sheetWork('homework', 'الواجب المنزلي')], 'الواجبات'); },
    all:        function(){ if(!needStudents()) return; return run([sheetStudents(), sheetAttendance(), sheetExams(), sheetQuiz('first', 'المذاكرة الأولى'), sheetQuiz('second', 'المذاكرة الثانية'), sheetBehavior(), sheetWork('classwork', 'الواجب الصفي'), sheetWork('homework', 'الواجب المنزلي')], 'ملف_شامل'); }
  };
  window.MalazExport = API;
  window.MalazExport._sheets = { students: sheetStudents, attendance: sheetAttendance, exams: sheetExams, quiz: sheetQuiz, behavior: sheetBehavior, work: sheetWork };

  /* ---------- الواجهة ---------- */
  function row(icon, label, hint, onclick){
    return '<div class="setting-menu-item" onclick="' + onclick + '"><div class="setting-item-lead"><div class="setting-icon-box" style="background:#E0E7FF;color:#3B5998;">' + icon + '</div><div><h4>' + label + '</h4>' + (hint ? '<p style="font-size:.7rem;color:var(--text-light);">' + hint + '</p>' : '') + '</div></div><div>›</div></div>';
  }
  function buildModal(){
    if(document.getElementById('exportCenterModal')) return;
    var html = '<div id="exportCenterModal" class="page-modal" onclick="closeModal(\'exportCenterModal\')"><div class="modal-content" onclick="event.stopPropagation()">' +
      '<div class="modal-header"><h3>📁 مركز التصدير والملفات</h3><button class="modal-close-btn" onclick="closeModal(\'exportCenterModal\')">✕</button></div>' +
      '<div id="mzLastFile" style="font-size:.75rem;color:var(--text-light);margin:0 0 8px;min-height:18px;">لم يُصدَّر أي ملف بعد في هذه الجلسة</div>' +
      '<div class="settings-section-title">📊 ملفات Excel (XLSX)</div><div class="settings-group-card">' +
      row('📋', 'كشف الطلاب', 'الإضبارة الكاملة', 'MalazExport.students()') +
      row('✅', 'الحضور والغياب', 'كل أيام الفصل الحالي', 'MalazExport.attendance()') +
      row('🎓', 'درجات الجلاء', 'مع المرتبة والمعدل', 'MalazExport.exams()') +
      row('📝', 'المذاكرات', 'الأولى والثانية', 'MalazExport.quizzes()') +
      row('🌟', 'السلوك والإملاء', 'الأسبوع الحالي والسابق', 'MalazExport.behavior()') +
      row('📚', 'الواجبات', 'الصفي والمنزلي', 'MalazExport.homework()') +
      row('🗂️', 'ملف شامل', 'كل ما سبق في ملف واحد', 'MalazExport.all()') +
      '</div><div class="settings-section-title">🖨️ PDF (معاينة ثم «طباعة» ثم «حفظ كـ PDF»)</div><div class="settings-group-card">' +
      row('👥', 'كشف الطلاب', '', "closeModal('exportCenterModal'); openPrintPreviewModal('students')") +
      row('✅', 'كشف الحضور', '', "closeModal('exportCenterModal'); openPrintPreviewModal('attendance')") +
      row('🎓', 'بطاقة الجلاء', '', "closeModal('exportCenterModal'); openPrintPreviewModal('exams')") +
      row('🗓️', 'جدول الحصص', '', "closeModal('exportCenterModal'); openPrintPreviewModal('schedule')") +
      row('💰', 'صندوق النشاط', '', "closeModal('exportCenterModal'); openPrintPreviewModal('fund')") +
      '</div><div class="settings-section-title">🖼️ صور</div><div class="settings-group-card">' +
      row('🗓️', 'جدول الحصص كصورة', 'PNG عالية الجودة', 'exportScheduleAsImage()') +
      '</div><div class="settings-section-title">💾 النسخ الاحتياطي</div><div class="settings-group-card">' +
      row('📥', 'تصدير نسخة احتياطية كاملة', 'JSON مع بصمة تحقق', 'exportBackupFile()') +
      row('📲', 'مشاركة النسخة الاحتياطية', 'واتساب / تيليغرام / سحابة', 'shareBackupFile()') +
      row('📤', 'استعادة من نسخة احتياطية', 'يُفحص الملف قبل الاستبدال', 'triggerImportBackup()') +
      '</div></div></div>';
    var d = document.createElement('div'); d.innerHTML = html; document.body.appendChild(d.firstChild);
  }
  window.openExportCenter = function(){ buildModal(); openModal('exportCenterModal'); };
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildModal); else buildModal();
})();
